#ifndef INTENTRECOGNIZER_INTENT_H
#define INTENTRECOGNIZER_INTENT_H
 #include <vector>
using namespace std;

class intent {
public:
  static string recognizer(string s);
};

#endif // INTENTRECOGNIZER_INTENT_H


